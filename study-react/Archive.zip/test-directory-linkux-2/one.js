this is my first time writing files thorugh th eterminal process.this I cna naman  now type freely:
